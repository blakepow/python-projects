# TODO: Add entry point code here
from game.dealer import Dealer

dealer = Dealer()
dealer.start_game()